#include <iostream>
#include "../include/vertice.hpp"


int Vertice::getCor() {
    return this->cor;
};

int Vertice::getNum() {
    return this->num;
};

void Vertice::setCor(int c) {
    this->cor = c;
};

void Vertice::setNum(int n) {
    this->num = n;
};



