#include <iostream>
#include <sstream>
#include "../include/vertice.hpp"
#include "../include/ordenacao.hpp"
#include "../include/aresta.hpp"



using std::cout;
using std::cin;


bool verficaColoracaoGulosa(Vertice *v, Aresta *a, int n) {

    for (int i = 0; i < n; i++)
    {
        int pos_aresta = v[i].getNum();

        if(v[i].getCor() == 1) continue;

        for (int j = 1; j < v[i].getCor(); j++)
        {
            if(a[pos_aresta].cor_vizinhos[j] == 0) {
                //cout << "O elemento" << v[i].getNum() << "De cor " << v[i].getCor() << "Não tem o viznho de cor" << j << std::endl;
                return false;
            }
        }
    }  

    return true;

};



void imprimirVetor(Vertice * v, int n) {

    for (int i = 0; i < n; i++)
    {
        cout << v[i].getNum() << " ";
    }
    cout << std::endl;

};


int main(int argc,char ** argv){

    int n, m, v, cor;

    char c;

    cin >> c >> n;

    int cores[n];

    Vertice grafo[n];
    Aresta arestas[n];
    

    for (int i = 0; i < n; i++)
    {
        cin >> m;

        grafo[i].setNum(i);
        //grafo[i].setVizinhos(m,n);

        arestas[i].setVizinhos(m,n);

        for (int j = 0; j < m; j++)
        {
            cin >> v;
            arestas[i].adicionaVizinho(v);
        }
        
    }

    for (int i = 0; i < n; i++)
    {
        cin >> cor;
        grafo[i].setCor(cor);
        cores[i] = cor;
        
    }

    for (int i = 0; i < n; i++)
    {
        arestas[i].constroiCoresVizinhos(cores);
        
    }

    //cout << "Antes ";
    //imprimirVetor(grafo, n);
    //bubbleSort(grafo, n);
    //selectionSort(grafo, n);
    //insertionSort(grafo, n);
    //quickSort(grafo,0,n-1);
    //mergeSort(grafo,0,n-1);
    //heapSort(grafo, n);
    //ountingSort(grafo, n, n, n);
    //countingSortByColor(grafo, n, n);
    //cout << "Depois ";   
    //imprimirVetor(grafo, n);
    //cout << "Esperado  0 4 5 1 3 2 ";
    
   
    
    
    /*
    for (int i = 0; i < n; i++)
    {
        cout << "Grafo Num: " << grafo[i].getNum( )<< " Cor: "  << grafo[i].getCor() << " Vizinhos " << arestas[i].num_vizinhos << std::endl;
        for (int j = 0; j < arestas[i].num_vizinhos; j++)
        {
            cout << "Vizinho " << j << " Valor " << arestas[i].vizinhos[j] << std::endl;;
        }
        cout << std::endl;
        for (int j = 0; j <= n; j++)
        {
            cout << "Pos " << j << " Valor " << arestas[i].cor_vizinhos[j] << " ";
        }

        cout << std::endl;  
        cout << std::endl;          
        
        // Pos 2 valor 2 pos 3 valor 1
        
    } */

    if(verficaColoracaoGulosa(grafo, arestas, n)) {
        cout << "1 ";
    } else {
        cout << "0" << std::endl;
        return 0;
    }
    
    //c = 'k';
    switch (c)
    {
    case 'b':
        /* bubble */
        bubbleSort(grafo, n);
        break;
    case 's':
        /* selection */
        selectionSort(grafo, n);
        break;
    case 'i':
        /* insertion */
        insertionSort(grafo, n);
        break;
    case 'q':
        /* quick */
        quickSort(grafo,0,n-1);
        break;
    case 'm':
        /* mergesort */
        mergeSort(grafo,0,n-1);
        break;
    case 'p':
        /* heapsort */
        heapSort(grafo, n);
        break;
    case 'y':
        countingSortByColor(grafo, n, n);
        break;
    
    default:
        break;
    }

    imprimirVetor(grafo, n);
    //cout << "Esperado  0 4 5 1 3 2 ";


    return 0;
}