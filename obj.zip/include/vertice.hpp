#ifndef GRAFO_H
#define GRAFO_H

#include <iostream>

// vizinho cor dele numero dele

class Vertice {


    int cor, num;

    

    public:

        int getCor();

        int getNum();

        void setCor(int c);

        void setNum(int n);




};


#endif
